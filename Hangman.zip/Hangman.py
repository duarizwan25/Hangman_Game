import random
import tkinter as tk
from tkinter import messagebox

def choose_random_word():
    words = ["ANT", "BEAR", "BEE", "BIRD", "CAMEL", "CAT", "CHEETAH", "CHICKEN", "CHIMPANZEE", "COW", "CROCODILE",
             "DEER", "DOG", "DOLPHIN", "DUCK", "EAGLE", "PHOENIX", "ARA", "CARINA", "NORMA", "ANDROMEDA", "ANTLIA",
             "APUS", "AQUARIUS", "AQUILA", "ARIES", "AURIGA", "BOÖTES", "CAELUM", "CAMELOPARDALIS", "CANCER", "ANKLE",
             "ARM", "BACK", "BEARD", "BLOOD", "BODY", "BONE", "BRAIN", "CHEEK", "CHEST", "CHIN", "EAR", "EARS", "ELBOW",
             "EYE", "EYES", "FACE", "FEET", "FINGER", "NEW YORK", "LOS ANGELES", "CHICAGO", "HOUSTON", "PHOENIX",
             "PHILADELPHIA", "SANANTONIO", "DALLAS", "SAN DIEGO", "SAN JOSE", "DETROIT", "SAN FRANCISCO", "AFGHANISTAN",
             "ALBANIA", "ALGERIA", "AMERICAN SAMOA", "ANDORRA", "ANGOLA", "ANGUILLA"]
    return random.choice(words)

def show_game_page():
    welcome_frame.pack_forget()
    game_frame.pack(fill=tk.BOTH, expand=True)

def display_word(word, guessed_letters):
    display = ''
    for letter in word:
        if letter in guessed_letters:
            display += letter
        else:
            display += '_'
    return display

def make_guess():
    guess = guess_entry.get().upper()
    guess_entry.delete(0, tk.END)

    if len(guess) != 1 or not guess.isalpha():
        messagebox.showerror("Error", "Please enter a single letter.")
        return

    if guess in guessed_letters:
        messagebox.showinfo("Info", "You already guessed that letter.")
        return

    guessed_letters.append(guess)

    if guess not in word:
        incorrect_guesses.append(guess)
        if len(incorrect_guesses) == max_attempts:
            messagebox.showinfo("Game Over", f"Sorry, you ran out of attempts. The word was: {word}")
            guess_button.config(state=tk.DISABLED)
    else:
        if all(letter in guessed_letters for letter in word):
            messagebox.showinfo("Congratulations!", f"You guessed the word: {word}")
            guess_button.config(state=tk.DISABLED)

    update_display()

def update_display():
    word_label.config(text=display_word(word, guessed_letters))
    incorrect_guesses_label.config(text=f"Incorrect Guesses: {' '.join(incorrect_guesses)}")

def reset_game():
    global word, guessed_letters, incorrect_guesses
    word = choose_random_word()
    guessed_letters = []
    incorrect_guesses = []
    guess_button.config(state=tk.NORMAL)
    update_display()

app = tk.Tk()
app.title("Hangman Game")
app.geometry("500x500")

# Welcome Page
welcome_frame = tk.Frame(app)
welcome_frame.pack(fill=tk.BOTH, expand=True)

# Load background image for the welcome page
welcome_bg_image = tk.PhotoImage(file="pg1.png")
welcome_bg_label = tk.Label(welcome_frame, image=welcome_bg_image)
welcome_bg_label.place(relwidth=1, relheight=1)

# Start button on the welcome page
start_button = tk.Button(welcome_frame, text="Start Game", command=show_game_page, font=("Helvetica", 16))
start_button.pack(side=tk.BOTTOM, pady=20)

# Hangman Game Page
game_frame = tk.Frame(app)

# Load background image for the game page
game_bg_image = tk.PhotoImage(file="pg2.png")
game_bg_label = tk.Label(game_frame, image=game_bg_image)
game_bg_label.place(relwidth=1, relheight=1)

# Colors
bg_color = "#282c34"
fg_color = "#61dafb"
btn_color = "#98c379"
entry_bg_color = "#3e4451"
entry_fg_color = "#abb2bf"

game_frame.configure(bg=bg_color)

word = choose_random_word()
guessed_letters = []
incorrect_guesses = []
max_attempts = 6

# Centering widgets in the game frame
word_label = tk.Label(game_frame, text=display_word(word, guessed_letters), font=('Arial', 24), fg=fg_color, bg=bg_color)
word_label.place(relx=0.5, rely=0.3, anchor=tk.CENTER)

guess_entry = tk.Entry(game_frame, font=("Helvetica", 20), bg=entry_bg_color, fg=entry_fg_color)
guess_entry.place(relx=0.5, rely=0.4, anchor=tk.CENTER)

guess_button = tk.Button(game_frame, text="Guess", command=make_guess, font=("Helvetica", 20), bg=btn_color, fg=bg_color)
guess_button.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

incorrect_guesses_label = tk.Label(game_frame, text=f"Incorrect Guesses: {' '.join(incorrect_guesses)}", font=("Helvetica", 20), fg=fg_color, bg=bg_color)
incorrect_guesses_label.place(relx=0.5, rely=0.6, anchor=tk.CENTER)

reset_button = tk.Button(game_frame, text="Play Again", command=reset_game, font=("Helvetica", 20), bg=btn_color, fg=bg_color)
reset_button.place(relx=0.5, rely=0.7, anchor=tk.CENTER)

app.mainloop()
